<?php
[
    "1st" => "Copy public folder from Doc and extract this in root folder of your project and delete zip file",

    "2nd" => "Copy ckeditor folder from Doc and extract this in public folder  and delete zip file",

    "3rd" => "Copy .env folder from Doc and paste this in root folder of your project and add .",

    "4th" => "In .env file change your baseurl",

    "5th" => "run this command in your project command window 'composer install' 'npm install' ",

    "5th" => "run this command in your project command window 'npm run dev' 'npm run watch' ",

    "6th" => "run the command 'php artisan storage:link'",

    "7th" => "Go to your browser and write your project url"

    // everthing ok ??
];
