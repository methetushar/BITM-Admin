<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Menu;
use Faker\Generator as Faker;

$factory->define(Menu::class, function (Faker $faker) {
    return [
        //
    ];
});
