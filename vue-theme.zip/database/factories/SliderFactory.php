<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Slider;
use Faker\Generator as Faker;

$factory->define(Slider::class, function (Faker $faker) {
    return [
        //
    ];
});
