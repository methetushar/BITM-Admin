<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Album;
use Faker\Generator as Faker;

$factory->define(Album::class, function (Faker $faker) {
    return [
        //
    ];
});
