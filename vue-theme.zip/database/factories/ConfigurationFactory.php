<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Configuration;
use Faker\Generator as Faker;

$factory->define(Configuration::class, function (Faker $faker) {
    return [
        //
    ];
});
