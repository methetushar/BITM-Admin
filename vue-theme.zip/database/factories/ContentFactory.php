<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Content;
use Faker\Generator as Faker;

$factory->define(Content::class, function (Faker $faker) {
    return [
        //
    ];
});
